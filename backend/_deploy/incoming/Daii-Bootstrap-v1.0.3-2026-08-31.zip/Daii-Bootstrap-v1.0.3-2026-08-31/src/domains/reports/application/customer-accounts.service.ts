import { Injectable } from '@nestjs/common';
import { SalesOrdersService } from '../../sales-orders/application/sales-orders.service';
import { CustomersService } from '../../crm/application/customers.service';
import { DepositsService } from '../../deposit-control/application/deposits.service';
import { ReturnsService } from '../../returns/application/returns.service';
import { FulfillmentService } from '../../fulfillment/application/fulfillment.service';
import { ShipmentService } from '../../shipment/application/shipment.service';
import { DeliveryService } from '../../delivery/application/delivery.service';
import { CustomerLedgerService } from '../../customer-finance/application/customer-ledger.service';
import { CustomerLedgerEntryType } from '../../customer-finance/domain/customer-ledger-entry-type';

export interface CustomerAccountEntry {
  type: 'sales_order' | 'deposit' | 'collection' | 'return';
  date: string;
  salesOrderId: string;
  orderNumber: string;
  reference: string;
  description: string;
  amount: string | null;
  status: string;
}

export interface CustomerAccountStatement {
  customerId: string;
  customerCode: string;
  customerName: string;
  totalOrdered: string;
  totalDeposited: string;
  totalCollected: string;
  totalRemitted: string;
  returnCount: number;
  entries: CustomerAccountEntry[];
}

export interface LedgerCustomerAccountEntry {
  type: CustomerLedgerEntryType;
  date: string;
  reference: string;
  description: string;
  salesOrderId: string | null;
  invoiceId: string | null;
  debit: string;
  credit: string;
  runningBalance: string;
  status: 'posted' | 'reversed';
}

export interface LedgerCustomerAccountStatement {
  customerId: string;
  customerCode: string;
  customerName: string;
  balance: string;
  creditLimit: string | null;
  availableCredit: string | null;
  overdueAmount: string;
  totalSales: string;
  totalPaid: string;
  totalReturns: string;
  totalOutstanding: string;
  entries: LedgerCustomerAccountEntry[];
}

/**
 * Customer Account Foundation (CTO directive, extended by the Customer
 * Financial Account / Invoice / AR phase). `getCustomerAccountStatement`
 * is now the PRIMARY statement, sourced from the real Customer Ledger
 * (`CustomerLedgerService`) — per the directive's own "الرصيد يحسب من
 * Customer Ledger" instruction — never a second parallel ledger, and
 * never a cached balance column. The ORIGINAL live-composition logic
 * (walking Sales Order → Deposit → Delivery/Collection → Returns
 * directly, with no persisted ledger) is kept, renamed
 * `getCustomerAccountReconciliation`, and exposed as a separate
 * `/reconcile` endpoint — valuable specifically because pre-rollout
 * historical orders have no Customer Ledger rows unless later backfilled
 * with an `opening_balance` entry (an ops action, not part of this
 * change), so the two can be compared to catch drift.
 */
@Injectable()
export class CustomerAccountsService {
  constructor(
    private readonly salesOrders: SalesOrdersService,
    private readonly customers: CustomersService,
    private readonly deposits: DepositsService,
    private readonly returns: ReturnsService,
    private readonly fulfillment: FulfillmentService,
    private readonly shipments: ShipmentService,
    private readonly delivery: DeliveryService,
    private readonly customerLedger: CustomerLedgerService,
  ) {}

  /** The new primary statement (CTO directive §8) — Date/Type/Reference/SalesOrder/Invoice/Debit/Credit/RunningBalance/Status, every row traceable to its own source document, balance computed live from the Customer Ledger. */
  async getCustomerAccountStatement(customerId: string, actorUserId: string): Promise<LedgerCustomerAccountStatement> {
    const customer = await this.customers.getCustomer(customerId, actorUserId); // Scope-checked, same gate every customer-scoped read in this codebase uses
    const [entries, creditSummary] = await Promise.all([
      this.customerLedger.listLedger(customerId),
      this.customerLedger.getCreditSummary(customerId),
    ]);

    let runningBalance = 0;
    let totalSales = 0;
    let totalPaid = 0;
    let totalReturns = 0;

    const mapped: LedgerCustomerAccountEntry[] = entries.map((entry) => {
      const amount = Number(entry.amount);
      const debit = entry.direction === 'debit' ? amount : 0;
      const credit = entry.direction === 'credit' ? amount : 0;
      if (entry.status === 'posted') {
        runningBalance += debit - credit;
        if (entry.entryType === 'sales_invoice') totalSales += debit;
        if (entry.entryType === 'payment') totalPaid += credit;
        if (entry.entryType === 'return_credit_note') totalReturns += credit;
      }
      return {
        type: entry.entryType,
        date: entry.entryDate.toISOString(),
        reference: entry.entryNumber,
        description: entry.reason ?? entry.entryType,
        salesOrderId: entry.salesOrderId,
        invoiceId: entry.invoiceId,
        debit: debit.toFixed(2),
        credit: credit.toFixed(2),
        runningBalance: runningBalance.toFixed(2),
        status: entry.status,
      };
    });

    return {
      customerId: customer.id,
      customerCode: customer.code,
      customerName: customer.name,
      balance: creditSummary.balance,
      creditLimit: creditSummary.creditLimit,
      availableCredit: creditSummary.availableCredit,
      overdueAmount: creditSummary.overdueAmount,
      totalSales: totalSales.toFixed(2),
      totalPaid: totalPaid.toFixed(2),
      totalReturns: totalReturns.toFixed(2),
      totalOutstanding: creditSummary.balance,
      entries: mapped,
    };
  }

  /**
   * The ORIGINAL Customer Account Foundation composition — kept verbatim
   * as a cross-check, not the primary statement any more. See this class's
   * own doc comment for why (historical orders predating the Customer
   * Ledger have no ledger rows to source from).
   *
   * Deliberately sequential per order (not batched) — a customer has a
   * small number of orders in practice, and this mirrors the exact same
   * per-order hop chain `DeliveryService.recordCollection`/`remitCollection`
   * already walk one order at a time; batching would mean either
   * duplicating that join logic outside the domains that own it, or a raw
   * multi-table SQL join that would cross the Cross-Domain Rule this whole
   * codebase otherwise holds to (DAII_DOMAIN_BOUNDARIES.md).
   */
  async getCustomerAccountReconciliation(customerId: string, actorUserId: string): Promise<CustomerAccountStatement> {
    const customer = await this.customers.getCustomer(customerId, actorUserId);

    const orders = (await this.salesOrders.listOrders(actorUserId)).filter((o) => o.customerId === customerId);
    const allReturns = await this.returns.listReturns();

    const entries: CustomerAccountEntry[] = [];
    let totalOrdered = 0;
    let totalDeposited = 0;
    let totalCollected = 0;
    let totalRemitted = 0;
    let returnCount = 0;

    for (const order of orders) {
      totalOrdered += Number(order.totalAmount);
      const status = await this.salesOrders.getOrderStatus(order.id);
      entries.push({
        type: 'sales_order',
        date: order.createdAt.toISOString(),
        salesOrderId: order.id,
        orderNumber: order.orderNumber,
        reference: order.orderNumber,
        description: `Sales Order ${order.orderNumber}`,
        amount: order.totalAmount,
        status,
      });

      const orderDeposits = await this.deposits.listDepositsForOrder(order.id, actorUserId);
      for (const dep of orderDeposits) {
        if (dep.status === 'approved') totalDeposited += Number(dep.amount);
        entries.push({
          type: 'deposit',
          date: dep.createdAt.toISOString(),
          salesOrderId: order.id,
          orderNumber: order.orderNumber,
          reference: dep.id,
          description: `Deposit (${dep.method})`,
          amount: dep.amount,
          status: dep.status,
        });
      }

      for (const ret of allReturns.filter((r) => r.salesOrderId === order.id)) {
        returnCount += 1;
        // Returns Engine (CTO directive §7 — ERP/AR readiness): a return
        // now carries a real credit amount when one was issued
        // (value_credit/product_return dispositions) — an exchange still
        // shows null, since no credit is ever created for one.
        const credit = await this.returns.getCreditForReturnRequest(ret.id);
        entries.push({
          type: 'return',
          date: ret.createdAt.toISOString(),
          salesOrderId: order.id,
          orderNumber: order.orderNumber,
          reference: ret.id,
          description: `Return — quantity ${ret.quantity} (${ret.reason})`,
          amount: credit?.originalAmount ?? null,
          status: ret.state,
        });
      }

      const fulfillmentOrder = await this.fulfillment.getFulfillmentOrderBySalesOrderId(order.id);
      const shipment = fulfillmentOrder ? await this.shipments.getShipmentByFulfillmentOrderId(fulfillmentOrder.id) : null;
      const collection = shipment ? await this.delivery.getCollectionForShipmentUnscoped(shipment.id) : null;
      if (shipment && collection) {
        totalCollected += Number(collection.amount);
        if (collection.remittanceStatus === 'remitted') totalRemitted += Number(collection.amount);
        entries.push({
          type: 'collection',
          date: collection.occurredAt.toISOString(),
          salesOrderId: order.id,
          orderNumber: order.orderNumber,
          reference: collection.id,
          description: `Collection (${collection.method}) — waybill ${shipment.waybillNumber}`,
          amount: collection.amount,
          status: collection.remittanceStatus,
        });
      }
    }

    entries.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    return {
      customerId: customer.id,
      customerCode: customer.code,
      customerName: customer.name,
      totalOrdered: totalOrdered.toFixed(2),
      totalDeposited: totalDeposited.toFixed(2),
      totalCollected: totalCollected.toFixed(2),
      totalRemitted: totalRemitted.toFixed(2),
      returnCount,
      entries,
    };
  }
}
