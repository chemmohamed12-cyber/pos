import { BadRequestException, Body, Controller, Get, Param, Post, Req, UseGuards, UseInterceptors, UploadedFile } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { IsIn, IsObject, IsUUID } from 'class-validator';
import { DataRepairService } from './data-repair.service';
import { DataRepairRun } from './data-repair-run.entity';
import { DataRepairKind } from './data-repair-status';
import { DeployPreflightService } from './deploy-preflight.service';
import { DataSource } from 'typeorm';
import { InjectDataSource } from '@nestjs/typeorm';
import { randomUUID } from 'crypto';
import { tmpdir } from 'os';
import { rm } from 'fs/promises';
import { BackupManagerService } from './backup-manager.service';
import { RestoreManagerService } from './restore-manager.service';
import { ReleaseManagerService } from './release-manager.service';
import { ReleaseExecutionService } from './release-execution.service';
import { BackupRun } from './backup-run.entity';
import { BackupArtifact } from './backup-artifact.entity';
import { RestoreOperation } from './restore-operation.entity';
import { Release } from './release.entity';
import { ReleaseMigrationRun } from './release-migration-run.entity';
import { ReleaseManifest } from './release-manifest';
import { ReleasePackageType } from './release-status';
import { readAppVersion } from './app-version';
import { JwtAuthGuard, AuthenticatedRequest } from '../authentication/jwt-auth.guard';
import { RolesGuard } from '../authorization/roles.guard';
import { RequireRole } from '../authorization/require-role.decorator';
import { PermissionGuard } from '../permission/permission.guard';
import { RequirePermission } from '../permission/require-permission.decorator';

/**
 * The manifest's own internal shape (`ReleaseManifest.files[]`
 * checksums, migrations, etc.) is validated by
 * `ReleaseManagerService.validateManifest` — the actual business rule
 * (CTO directive §9/§10), not re-implemented here as nested
 * class-validator decorators. This DTO only checks the envelope fields
 * a controller genuinely owns: which endpoint/permission applies
 * (`packageType`) and that a manifest object was sent at all.
 */
class RegisterReleaseDto {
  @IsIn(['full', 'delta'])
  packageType!: ReleasePackageType;

  @IsObject()
  manifest!: ReleaseManifest;
}

class LinkBackupDto {
  @IsUUID()
  backupRunId!: string;
}

class CreateDataRepairDto {
  @IsIn(['uuid_rfc4122'])
  kind!: DataRepairKind;
}

/**
 * Release Center — Phases A (Backup) + B (Restore). Two guard layers:
 *
 * - `RolesGuard`/`@RequireRole('admin')` at the class level — the proven,
 *   everywhere-used coarse gate (same pattern as `AdminController`).
 *   Nobody who isn't already an admin reaches ANY route here.
 * - `PermissionGuard`/`@RequirePermission` per-route — the Permission
 *   Engine's first real production use. Read endpoints check
 *   `system.release.view`; write/action endpoints check the specific
 *   action node (`system.release.backup`, `system.release.restore`, and
 *   `system.release.deploy`/`system.release.rollback` once Phase C adds
 *   them) — the exact node names the CTO directive specified. The
 *   Permission Engine has NO admin auto-bypass (confirmed by reading
 *   `permission.service.ts` directly) — the `AddReleaseBackupTables`
 *   migration grants `admin` 'editable' at the PARENT `system.release`
 *   node, which covers every current and future child node
 *   (`system.release.*`) via the engine's own ancestor-chain walk, with
 *   zero further migration needed as new leaf nodes are added.
 */
@Controller('release')
@UseGuards(JwtAuthGuard, RolesGuard)
@RequireRole('admin')
export class ReleaseController {
  constructor(
    private readonly backupManager: BackupManagerService,
    private readonly restoreManager: RestoreManagerService,
    private readonly releaseManager: ReleaseManagerService,
    private readonly releaseExecution: ReleaseExecutionService,
    private readonly dataRepair: DataRepairService,
    private readonly deployPreflight: DeployPreflightService,
    @InjectDataSource() private readonly dataSource: DataSource,
  ) {}

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.view', 'read-only')
  @Get('backups')
  async listBackups() {
    return this.dataSource.getRepository(BackupRun).find({ order: { startedAt: 'DESC' }, take: 100 });
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.view', 'read-only')
  @Get('backups/:id')
  async getBackup(@Param('id') id: string) {
    const run = await this.dataSource.getRepository(BackupRun).findOne({ where: { id } });
    const artifacts = await this.dataSource.getRepository(BackupArtifact).find({ where: { backupRunId: id } });
    return { run, artifacts };
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.backup', 'editable')
  @Post('backups')
  async createBackup(@Req() req: AuthenticatedRequest) {
    return this.backupManager.createBackup('manual', req.user.id);
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.backup', 'editable')
  @Post('backups/artifacts/:artifactId/verify')
  async reverifyBackupArtifact(@Param('artifactId') artifactId: string) {
    return this.backupManager.reverifyArtifact(artifactId);
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.view', 'read-only')
  @Get('restores/:id')
  async getRestore(@Param('id') id: string) {
    return this.dataSource.getRepository(RestoreOperation).findOne({ where: { id } });
  }

  /** Step 1 of 2 — read-only, never touches the database. Returns a `RestoreOperation` a human must review before calling `confirm` below. */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.restore', 'editable')
  @Post('backups/:backupRunId/restore/preflight')
  async preflightRestore(@Param('backupRunId') backupRunId: string, @Req() req: AuthenticatedRequest) {
    return this.restoreManager.preflight(backupRunId, req.user.id);
  }

  /** Step 2 of 2 — the only endpoint in this codebase that actually overwrites live database content. Requires a `pending_confirmation` operation from `preflight` above, within its confirmation window. */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.restore', 'editable')
  @Post('restores/:id/confirm')
  async confirmRestore(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
    return this.restoreManager.confirmAndRestore(id, req.user.id);
  }

  // --- Phase C (foundation slice): register/validate a release manifest,
  // link it to a verified backup, and check the mandatory deployment
  // gate. Actual file deployment/migration execution/health-check/
  // rollback endpoints are the next increment — see
  // `ReleaseManagerService`'s doc comment for the explicit scope boundary.

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.view', 'read-only')
  @Get('releases')
  async listReleases() {
    return this.dataSource.getRepository(Release).find({ order: { uploadedAt: 'DESC' }, take: 100 });
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.view', 'read-only')
  @Get('releases/:id')
  async getRelease(@Param('id') id: string) {
    return this.dataSource.getRepository(Release).findOne({ where: { id } });
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.deploy', 'editable')
  @Post('releases')
  async registerRelease(@Body() dto: RegisterReleaseDto, @Req() req: AuthenticatedRequest) {
    return this.releaseManager.registerRelease(dto.manifest, dto.packageType, req.user.id);
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.deploy', 'editable')
  @Post('releases/:id/link-backup')
  async linkReleaseBackup(@Param('id') id: string, @Body() dto: LinkBackupDto, @Req() req: AuthenticatedRequest) {
    return this.releaseManager.linkVerifiedBackup(id, dto.backupRunId, req.user.id);
  }

  /** Read-only check — "would a deploy be allowed right now." Never itself deploys anything. */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.deploy', 'read-only')
  @Get('releases/:id/deployment-gate')
  async checkDeploymentGate(@Param('id') id: string) {
    return this.releaseManager.checkDeploymentGate(id);
  }

  /** Read-only host/environment readiness (binaries, disk, DB, paths). Run before a deploy; the deploy runs it again itself (with the staged package) and STOPs on any critical fail. */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.deploy', 'read-only')
  @Get('preflight')
  async deployPreflightCheck() {
    return this.deployPreflight.runPreflight();
  }

  // --- Execution Layer: real ZIP upload/staging, deploy, rollback, and
  // per-migration traceability. See `ReleaseExecutionService` doc comment
  // for the full pipeline and the migration-DataSource technical note.

  /** The current installed application version — for the UI's header. */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.view', 'read-only')
  @Get('version')
  getVersion() {
    return { version: readAppVersion() };
  }

  /** The real ZIP-upload entry point — validates, stages, and registers the release in one call. `registerRelease` (JSON-only, above) stays for tooling/tests that don't need a real zip. */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.deploy', 'editable')
  @Post('releases/upload')
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({ destination: tmpdir(), filename: (_req, _file, cb) => cb(null, `release-upload-${randomUUID()}.zip`) }),
      limits: { fileSize: 200 * 1024 * 1024 },
    }),
  )
  async uploadRelease(@UploadedFile() file: Express.Multer.File, @Body('packageType') packageType: string, @Req() req: AuthenticatedRequest) {
    if (!file) throw new BadRequestException('No file uploaded — expected a multipart "file" field containing the release ZIP.');
    if (packageType !== 'full' && packageType !== 'delta') {
      await rm(file.path, { force: true });
      throw new BadRequestException('packageType must be "full" or "delta".');
    }
    try {
      return await this.releaseExecution.uploadPackage(file.path, packageType, req.user.id);
    } finally {
      await rm(file.path, { force: true });
    }
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.deploy', 'editable')
  @Post('releases/:id/deploy')
  async deployRelease(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
    return this.releaseExecution.deployRelease(id, req.user.id);
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.rollback', 'editable')
  @Post('releases/:id/rollback')
  async rollbackRelease(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
    return this.releaseExecution.rollbackRelease(id, req.user.id);
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.view', 'read-only')
  @Get('releases/:id/migrations')
  async getReleaseMigrations(@Param('id') id: string) {
    return this.dataSource.getRepository(ReleaseMigrationRun).find({ where: { releaseId: id }, order: { startedAt: 'ASC' } });
  }

  // --- Controlled Data Repair: audit -> plan mapping -> link verified
  // backup -> execute (one transaction) -> verify integrity. Reuses the
  // `system.release.restore` permission node for mutations (destructive,
  // backup-gated, same risk class as a restore) and `system.release.view`
  // for reads. See `DataRepairService` for the full flow and why it is a
  // first-class capability rather than a runbook.

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.view', 'read-only')
  @Get('data-repairs')
  async listDataRepairs() {
    return this.dataRepair.list();
  }

  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.view', 'read-only')
  @Get('data-repairs/:id')
  async getDataRepair(@Param('id') id: string): Promise<DataRepairRun> {
    return this.dataRepair.get(id);
  }

  /** Step 1 — create the run and capture the read-only UUID audit. Nothing in any business table changes. */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.restore', 'editable')
  @Post('data-repairs')
  async createDataRepair(@Body() dto: CreateDataRepairDto, @Req() req: AuthenticatedRequest) {
    return this.dataRepair.createAndAudit(dto.kind, req.user.id);
  }

  /** Step 2 — generate the reviewable old→new id mapping (read-only). */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.restore', 'editable')
  @Post('data-repairs/:id/plan')
  async planDataRepair(@Param('id') id: string) {
    return this.dataRepair.plan(id);
  }

  /** Step 3 — tie a VERIFIED pre-repair backup to this repair (the gate). */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.restore', 'editable')
  @Post('data-repairs/:id/link-backup')
  async linkDataRepairBackup(@Param('id') id: string, @Body() dto: LinkBackupDto, @Req() req: AuthenticatedRequest) {
    return this.dataRepair.linkVerifiedBackup(id, dto.backupRunId, req.user.id);
  }

  /** Step 4 — run the repair in one transaction, then verify integrity. Only a "backup_linked" repair can be executed. */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.restore', 'editable')
  @Post('data-repairs/:id/execute')
  async executeDataRepair(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
    return this.dataRepair.execute(id, req.user.id);
  }

  /** Read-only — re-run integrity verification against the current DB state (e.g. after a restore). Does not mutate the stored run. */
  @UseGuards(PermissionGuard)
  @RequirePermission('system.release.view', 'read-only')
  @Get('data-repairs/verify/now')
  async verifyDataRepairNow() {
    return this.dataRepair.verifyNow();
  }
}
