import { Injectable, NotFoundException } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { NumberingSequence } from './numbering-sequence.entity';

interface SequenceRow {
  documentType: string;
  prefix: string;
  includeYear: boolean;
  lastNumber: number;
  lastYear: number | null;
}

/**
 * Numbering Engine — Stage 2 build-order item 17.
 * Daii/architecture/DAII_PLATFORM_FOUNDATION_CONTRACT.md §12.
 *
 * Issuance is transactional with a row lock (`SELECT ... FOR UPDATE`) on
 * the sequence row — two concurrent callers for the same document type
 * cannot receive the same number, closing the concurrency gap `baseline`'s
 * free-standing counter never had a guarantee against.
 */
@Injectable()
export class NumberingService {
  constructor(private readonly dataSource: DataSource) {}

  async registerDocumentType(documentType: string, prefix: string, includeYear = true): Promise<void> {
    const repo = this.dataSource.getRepository(NumberingSequence);
    const existing = await repo.findOne({ where: { documentType } });
    if (existing) return; // idempotent
    await repo.save(repo.create({ documentType, prefix, includeYear, lastNumber: 0, lastYear: null }));
  }

  async getNextNumber(documentType: string): Promise<string> {
    return this.dataSource.transaction(async (manager) => {
      const rows: SequenceRow[] = await manager.query(
        'SELECT * FROM numbering_sequences WHERE "documentType" = $1 FOR UPDATE',
        [documentType],
      );
      if (rows.length === 0) {
        throw new NotFoundException(`No numbering sequence registered for document type "${documentType}".`);
      }
      const seq = rows[0];
      const currentYear = new Date().getFullYear();

      let nextNumber: number;
      let yearToUse: number;
      if (seq.includeYear && seq.lastYear !== currentYear) {
        nextNumber = 1; // year rollover resets the running count
        yearToUse = currentYear;
      } else {
        nextNumber = seq.lastNumber + 1;
        yearToUse = seq.lastYear ?? currentYear;
      }

      await manager.query(
        'UPDATE numbering_sequences SET "lastNumber" = $1, "lastYear" = $2, "updatedAt" = now() WHERE "documentType" = $3',
        [nextNumber, yearToUse, documentType],
      );

      const padded = String(nextNumber).padStart(6, '0');
      return seq.includeYear ? `${seq.prefix}-${yearToUse}-${padded}` : `${seq.prefix}-${padded}`;
    });
  }

  /**
   * The TD-29 fix: cross-checks the registry against an externally-known
   * maximum (e.g. after a bulk import or a restore that bypassed normal
   * issuance) and bumps the counter forward if the registry undercounts.
   * Never moves the counter backward — that would risk reissuing a
   * number already in use, exactly the defect this method exists to
   * prevent.
   */
  async reconcileAgainstObservedMax(documentType: string, observedMaxNumber: number): Promise<void> {
    await this.dataSource.transaction(async (manager) => {
      await manager.query(
        'UPDATE numbering_sequences SET "lastNumber" = GREATEST("lastNumber", $1) WHERE "documentType" = $2',
        [observedMaxNumber, documentType],
      );
    });
  }
}
