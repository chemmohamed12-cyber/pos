# Backup Gate Fix v2 — 12-file surgical delta

Fixes the runtime crash `Cannot read properties of undefined (reading 'split')`
in the first Backup Gate Fix: `verifyDumpStructure` called `stdout.split()`
unconditionally, but a CloudLinux `pg_restore` shim can resolve **exit 0**
with a non-string `stdout`. v2 treats **exit code 0 from `pg_restore --list`
as proof the archive is valid** (stdout is only used for the human-readable
entry count) and coerces every `stdout`/`stderr` read through a string
guard.

**Preserved from v1:** 64 MiB `maxBuffer`, PGDMP magic validation in
`dump()`, detailed-but-redacted error reporting.

**Supersedes `Daii-BackupGateFix-Delta-2026-08-31.zip`
(`9c59442196fbcd19600eb2830215ba5b70d5e82177f4ecf76c49ea33c29f6a3c`).**
Safe to apply whether or not that one was applied — it is a complete,
self-consistent overlay of the same 3 modules.

**12-file overlay. `rsync` WITHOUT `--delete`. No migrations, no
`npm install`, no dependency change. UUID Repair Run
`03c435b6-b6e0-44d4-b0dc-1c1f0ecc6f70` is not touched. Do NOT create a new
backup.**

## Files (paths mirror `<AppRoot>` = `/home/xnexdrgr/daii.xnexustech.com/release-new/backend`)

```
src/foundation/release/{pg-dump-runner.service,backup-manager.service,release.controller}.ts
dist/foundation/release/{pg-dump-runner.service,backup-manager.service,release.controller}.{js,d.ts,js.map}
```
(only `pg-dump-runner.service.*` changed vs the v1 delta; the other two are byte-identical to v1 and are re-shipped so the overlay is complete either way.)

## Steps

```bash
AR=/home/xnexdrgr/daii.xnexustech.com/release-new/backend
cd <extracted>/Daii-BackupGateFix-Delta-v2-2026-08-31

# 0. integrity of this package
sha256sum -c MANIFEST.sha256                          # OK for all 12

# 1. local rollback copy of the 3 files being replaced
for f in pg-dump-runner.service backup-manager.service release.controller; do
  cp -a "$AR/dist/foundation/release/$f.js" "$AR/dist/foundation/release/$f.js.pre-bgf2"
done

# 2. overlay — NO --delete
rsync -a  src/foundation/release/  "$AR/src/foundation/release/"
rsync -a  dist/foundation/release/ "$AR/dist/foundation/release/"

# 3. confirm the running dist now has v2
grep -c 'asText'    "$AR/dist/foundation/release/pg-dump-runner.service.js"          # >= 5
grep -c 'maxBuffer' "$AR/dist/foundation/release/pg-dump-runner.service.js"          # >= 3   (preserved)
grep -c 'PGDMP'     "$AR/dist/foundation/release/pg-dump-runner.service.js"          # >= 1   (preserved)
grep -n 'exited 0 (archive is parseable' "$AR/dist/foundation/release/pg-dump-runner.service.js"   # present
grep -nE 'stdout\.split' "$AR/dist/foundation/release/pg-dump-runner.service.js"     # must show it guarded: `stdout ? stdout.split(...)`

# 4. restart Passenger
touch "$AR/tmp/restart.txt"
```

## Re-verify the EXISTING artifact

```bash
curl -sS -X POST \
  "https://daii.xnexustech.com/api/release/backups/artifacts/316abf30-f3ac-41f8-8046-b6c9de96d2c1/verify" \
  -H "Authorization: Bearer <ADMIN_JWT>" -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 daii-ops" --data '{}'

curl -sS "https://daii.xnexustech.com/api/release/backups/3facc830-ed83-42f1-86d4-97bc76d5b81e" \
  -H "Authorization: Bearer <ADMIN_JWT>" -H "User-Agent: Mozilla/5.0 daii-ops"
```

**Acceptance (must all hold):**
- the `database` artifact → `status: "verified"`, `verifiedAt` set, `errorMessage: null`
- same artifact id `316abf30-f3ac-41f8-8046-b6c9de96d2c1`
- `run.status` = `"completed"` (or `"partially_failed"` only if the media artifact isn't verified — the DB artifact `verified` is what the gate needs)
- `GET /api/release/data-repairs/03c435b6-b6e0-44d4-b0dc-1c1f0ecc6f70` still `status: "planned"`, `auditResult` + `mapping` unchanged

**Then STOP. Do NOT link the backup or execute the repair until explicitly instructed.**

## If it STILL fails

The artifact `errorMessage` now carries the real `pg_restore` reason. If it
shows a **checksum mismatch**, the dump on disk differs from what the
artifact recorded at creation — that means the file was regenerated after
the artifact row was written; the artifact cannot be salvaged (its checksum
is frozen). **Stop and report the mismatch** — do not create a new backup
or move files without instruction.
