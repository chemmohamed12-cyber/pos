# Backup Gate Fix — Report

**Trigger:** Backup Run `db3f41b7-a3ad-40a4-831a-65854d968e12` — media artifact
`verified`, **database artifact `verification_failed`**:
`pg_restore --list could not parse the dump — archive is not structurally valid`;
new `POST /api/release/backups` returning **LiteSpeed 403**.

**Nothing was executed against the server. The UUID Data Repair Run (Audit +
Plan) is untouched. No repair was run. No cleanup.**

---

## 1. Cause

The failed `.dump` file is **plain-SQL text, not a PostgreSQL custom-format
(`-Fc`) archive** — the operator's own log line
`pg_restore: input file appears to be a text format dump` is the tell.

`pg_dump` exited 0, so `PgDumpRunnerService.dump()` returned successfully;
`BackupManagerService` then checksummed the (bad) file, recorded it as a
`completed` artifact, and only `verifyArtifact` → `pg_restore --list` caught
that it isn't a real archive — **after** it was already an artifact.

Why a text file:

- **`PG_DUMP_BIN` is almost certainly unset** on the server. It defaults to the
  bare string `pg_dump` (`configuration.schema.ts`), so `execFile` resolves it
  via the **Passenger process PATH** — the same PATH that in the v1.0.3
  deployment didn't have `node`/`npm`. Whatever `pg_dump` that PATH exposes
  (a CloudLinux version wrapper, an old client, or `pg_dumpall`) is not
  honouring `--format=custom`/`-Fc` and is emitting plain SQL.
- Secondary latent defect: `verifyDumpStructure` ran `pg_restore --list` with
  `execFile`'s **default 1 MiB `maxBuffer`**. For a schema this size the
  table-of-contents can exceed 1 MiB → `execFileAsync` throws
  `stdout maxBuffer exceeded` → the old code swallowed it as
  `return false` → a *valid* dump would also be reported "not structurally
  valid". Not necessarily the cause here, but it would mask the real one.

**The 403** is a **LiteSpeed/ModSecurity** decision, not application code. The
most plausible contributor from our side: the previous failed response body
contained raw `pg_restore:` stderr **and absolute filesystem paths**
(`/home/xnexdrgr/backups/daii/db/…`), which an **outbound** ModSecurity rule
(path disclosure / SQL-ish content) can 403 — poisoning subsequent requests.
The inbound side (an empty authenticated `POST` being 403'd) is a host rule
that must be handled operator-side (see §4), not bypassed.

---

## 2. The fix (source — the correct place)

### `src/foundation/release/pg-dump-runner.service.ts`
- `dump()` now, **before any artifact is recorded**:
  1. runs `pg_dump` with explicit long-form args (`--format=custom --file
     <path> --dbname <db> --no-password`) and `maxBuffer: 64 MiB`, and
     **captures stderr**;
  2. asserts the output file exists and is **non-empty**;
  3. asserts the first 5 bytes are the **`PGDMP`** custom-format magic — a
     plain-text file (wrong binary / `-Fc` ignored) **fails here** with a
     message that names the binary path and pg_dump's stderr;
  4. runs `pg_restore --list` as the **definitive** structural check.
  → A dump that cannot be restored is **never** recorded as an artifact; the
  Backup Run fails immediately with the real reason.
- `verifyDumpStructure()` return type changed `Promise<boolean>` →
  `Promise<{ ok, detail }>`. `maxBuffer` bumped to 64 MiB. `detail` carries
  the **actual `pg_restore` message + the binary path** on failure, or the
  TOC entry count on success.
- Every failure message includes a **binary hint**: if `PG_DUMP_BIN` /
  `PG_RESTORE_BIN` is not an absolute path, the error says so and points at
  `PRODUCTION_DEPLOYMENT_GUIDE.md`.
- `restore()` also gets `maxBuffer: 64 MiB` + the binary hint.

### `src/foundation/release/backup-manager.service.ts`
- `verifyArtifact()` records the **detailed** reason from `verifyDumpStructure`
  on `artifact.errorMessage` (the pg_restore message + which binary), not the
  old generic `"not structurally valid"` string. Detail also lands in
  `audit_records` and the on-disk `<backup-storage>/manifests/<runId>.json`.

### `src/foundation/release/release.controller.ts`
- Backup responses (`GET /backups`, `GET /backups/:id`, `POST /backups`,
  `POST /backups/artifacts/:id/verify`) are passed through
  `redactErrorForResponse()` — collapses absolute paths to `<path>`, strips
  raw multi-line tool stderr, caps `errorMessage` at 400 chars. **The stored
  value is untouched** (the operator reads the full detail from the on-disk
  backup manifest / DB / server log). This removes the outbound-ModSecurity
  trigger and the information-disclosure smell. **ModSecurity itself is not
  touched.**

Regression tests: `pg-dump-runner.service.spec.ts` rewritten (real temp
files + per-call `execFile` wiring) — 8 tests incl. plain-text rejection,
0-byte rejection, `pg_restore --list` unparseable rejection, and the happy
path. `backup-manager.service.spec.ts` updated for the new return shape and
now asserts the artifact carries the real pg_restore message. Full suite:
**57 suites / 696 tests green**; build + dist-integrity + structure clean.

---

## 3. What changed (file list)

| File | Change |
|---|---|
| `src/foundation/release/pg-dump-runner.service.ts` | magic-byte + empty-file guard, `pg_restore --list` inside `dump()`, `maxBuffer` 64 MiB, stderr capture, binary-path hints, `verifyDumpStructure` → `{ok,detail}` |
| `src/foundation/release/backup-manager.service.ts` | `verifyArtifact` records the real `pg_restore` reason on the artifact |
| `src/foundation/release/release.controller.ts` | `redactErrorForResponse()` on the 4 backup endpoints |
| `src/foundation/release/pg-dump-runner.service.spec.ts` | rewritten (8 tests) |
| `src/foundation/release/backup-manager.service.spec.ts` | updated for the new return shape (+ asserts the real message) |
| `dist/**` twins of the 3 source files | rebuilt |

Repackaged into `Daii-Bootstrap-v1.0.3-2026-08-31.zip` — new SHA-256
**`d07ea5f9a60f3faa1592920b711b303dc1d730936acab1c949ec9c74a077c185`**
(1494 files; delta unchanged: ADDED 140 / MODIFIED 29 / UNCHANGED 1293 /
REMOVED 45; fresh-extract verification 12/12 PASSED).

**If the previous bootstrap was already rsync'd to the host, the only delta is
6 files:** `src/foundation/release/{pg-dump-runner.service,backup-manager.service,release.controller}.ts`
+ their `dist/**` twins. Re-`rsync` just `src/foundation/release/` +
`dist/foundation/release/` (`rsync -a --delete`), then `touch tmp/restart.txt`.

---

## 4. Shortest next operational step

**Step A — set the binary paths (the actual cause):** on the host,
```bash
which pg_dump pg_restore
# or, matching the app's DB server (PostgreSQL 10.x):
ls /usr/pgsql-*/bin/pg_dump  ;  ls /opt/*/pgsql*/bin/pg_dump 2>/dev/null
```
Set **absolute** values in cPanel → Setup Node.js App → Environment variables:
```
PG_DUMP_BIN     = <absolute path>/pg_dump       # major version >= the DB's 10.x
PG_RESTORE_BIN  = <absolute path>/pg_restore
```
`touch tmp/restart.txt`.

**Step B — re-deploy the fix** (6 files, §3) if the old bootstrap was applied;
`touch tmp/restart.txt`.

**Step C — take a NEW backup** (`db3f41b7`'s db file is bad and its recorded
checksum is of the bad file — it cannot be salvaged; keep the row for the
audit trail, do not delete it):
```bash
curl -sS -X POST https://daii.xnexustech.com/api/release/backups \
  -H "Authorization: Bearer <admin-jwt>" \
  -H "Content-Type: application/json" -H "User-Agent: daii-ops" -d '{}'
```
The `Content-Type` + `User-Agent` + body `{}` headers matter — an empty POST
with no `Content-Type` is the most common inbound ModSecurity 403. If it still
403s, read the LiteSpeed error log for the **rule ID**, and have the host
**whitelist that one rule for `/api/release/*` only** (`SecRuleRemoveById` in a
`.htaccess`/`LSWS` context for that path) — **do not disable ModSecurity**.

With the fixed code, the response is one of:
- `status: "completed"`, db artifact `status: "verified"` → **Step D**;
- `status: "failed"`, db artifact `errorMessage` naming the exact reason
  (wrong binary, still text, permission, quota) → fix that, retry.

**Step D — verify + link + repair (once the db artifact is `verified`):**
```bash
NEW_RUN=<backupRunId from Step C>
REPAIR=<the existing data_repair_run id — Audit+Plan already done>

# link the verified backup to the EXISTING repair run (does NOT touch audit/plan)
curl -sS -X POST https://daii.xnexustech.com/api/release/data-repairs/$REPAIR/link-backup \
  -H "Authorization: Bearer <admin-jwt>" -H "Content-Type: application/json" -H "User-Agent: daii-ops" \
  -d "{\"backupRunId\":\"$NEW_RUN\"}"        # → status: "backup_linked"

# then execute the repair (one transaction; uses the stored old->new mapping verbatim — no re-audit, no re-plan)
curl -sS -X POST https://daii.xnexustech.com/api/release/data-repairs/$REPAIR/execute \
  -H "Authorization: Bearer <admin-jwt>" -H "Content-Type: application/json" -H "User-Agent: daii-ops" -d '{}'
```

Then stop and report the `execute` result (`rowsRepaired`, `integrityResult`)
before the application-level flow re-test.

---

## Acceptance status

| Criterion | State |
|---|---|
| Database Backup Artifact = verified | **pending Step C** on the host (code fix in place; cause is `PG_DUMP_BIN`) |
| Backup Run valid as Verified Backup Gate | pending Step C |
| UUID Repair = not executed | ✅ untouched |
| Audit + Plan preserved | ✅ untouched — `link-backup` + `execute` do not re-run them |
| No server cleanup | ✅ |
| No data change outside the required backup | ✅ — no repair run, no DB writes |
| No new Workstream | ✅ — fix folded into the existing v1.0.3 bootstrap |
