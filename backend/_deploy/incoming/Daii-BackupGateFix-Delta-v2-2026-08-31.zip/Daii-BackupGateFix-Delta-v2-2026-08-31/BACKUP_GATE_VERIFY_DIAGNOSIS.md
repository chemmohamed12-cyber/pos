# Backup Gate — why `verifyArtifact` still fails a valid PGDMP dump

**Artifact `316abf30-f3ac-41f8-8046-b6c9de96d2c1`** (Backup Run
`3facc830-ed83-42f1-86d4-97bc76d5b81e`) — re-verify now reaches the app
(HTTP 201) but the DB artifact stays `verification_failed`:

> `pg_restore --list could not parse the dump — archive is not structurally valid.`

**Diagnosis only. No fix, no workaround, no data repair. UUID Repair Run
`03c435b6-…ecc6f70` untouched. No new backup.**

---

## Finding 1 — the running `dist` does NOT have the Backup Gate Fix

That exact error string — em-dash, ending `"structurally valid."` — is the
**pre-fix** message
(`backup-manager.service.ts`, before `d07ea5f9…`). The fix replaced it with:

> `pg_restore --list could not parse the dump: <the real pg_restore stderr + which binary>`

So the artifact's `errorMessage` is **not telling you the real reason** —
the old code only logs that to the Passenger stderr log and returns a generic
string.

**Confirm the running version (read-only):**
```bash
cd /home/xnexdrgr/daii.xnexustech.com/release-new/backend
grep -c 'maxBuffer'  dist/foundation/release/pg-dump-runner.service.js       # fixed => >= 3 ; old => 0
grep -n 'structural\|structurallyValid\|not structurally valid' \
     dist/foundation/release/backup-manager.service.js
#   fixed  => `if (!structural.ok)` + `could not parse the dump: ${structural.detail}`
#   old    => `if (!structurallyValid)` + `— archive is not structurally valid.`
grep -c 'PGDMP' dist/foundation/release/pg-dump-runner.service.js            # fixed => 1 ; old => 0
```

---

## Finding 2 — the real reason is already in the Passenger stderr log, right now

The **old** `verifyDumpStructure` does:
```ts
} catch (err) {
  this.logger.warn(`pg_restore --list failed for "${filePath}": ${err.message}`);
  return false;
}
```
So the real failure is in `stderr.log` already — no change needed to read it:

```bash
cd /home/xnexdrgr/daii.xnexustech.com/release-new/backend
grep -n 'pg_restore --list failed' stderr.log | tail -5
grep -A3 'pg_restore --list failed' stderr.log | tail -30
```

Read the message after `pg_restore --list failed for "...":` — it is one of:

| stderr.log message | Meaning | Note |
|---|---|---|
| `stdout maxBuffer length exceeded` / `maxBuffer` | The dump is FINE. `pg_restore --list`'s table-of-contents is larger than `execFile`'s default **1 MiB** buffer, so Node killed it. | The fix (`d07ea5f9…`) sets `maxBuffer` to 64 MiB. |
| `Command failed: /bin/pg_restore --list … \n pg_restore: … unsupported version (1.1x) in file header` | `/bin/pg_restore` is an **older major version** than the `pg_dump` that made the archive. | See Finding 3. |
| `pg_restore: error while loading shared libraries: libpq.so.5: cannot open shared object file` | `/bin/pg_restore` runs interactively but not inside the Passenger/CloudLinux-LVE process env (missing `LD_LIBRARY_PATH`). | The app's `execFile` inherits the Passenger process env, which is stripped. |
| `ENOENT` / `spawn /bin/pg_restore ENOENT` | `/bin/pg_restore` is not resolvable / not executable from the app process. | `/bin` may not be a real dir in the LVE jail; use the real path. |
| `Command failed: … \n pg_restore: … did not find magic string in file header` | The file the APP is reading is not the one you verified — different `RELEASE_BACKUP_STORAGE_PATH`. | See Finding 4. |
| a `timeout` / killed after 60s | `pg_restore --list` is hanging (rare for `--list`). | — |

---

## Finding 3 — run the EXACT command the app runs, against the SAME file

The app runs (both old and fixed code):
```
execFile("/bin/pg_restore", ["--list", "<absolutePath>"])
```
where `<absolutePath>` = `${RELEASE_BACKUP_STORAGE_PATH}/db/3facc830-ed83-42f1-86d4-97bc76d5b81e.dump`.

Run it **as the same OS user the app runs as** (`xnexdrgr`), from a plain
shell:
```bash
F=/home/xnexdrgr/backups/daii/db/3facc830-ed83-42f1-86d4-97bc76d5b81e.dump
ls -l "$F"                                   # confirm this is the file you manually verified
head -c 5 "$F"; echo                          # must print: PGDMP
head -c 12 "$F" | od -An -tx1                  # PGDMP + 3 version bytes, e.g. 50 47 44 4d 50  01 0e 00  -> archive fmt 1.14

/bin/pg_restore --list "$F"; echo "EXIT=$?"    # <-- THIS is the app's exact call
/bin/pg_restore --list "$F" | wc -c            # TOC size in bytes — compare to 1048576 (1 MiB)
/bin/pg_restore --version
/bin/pg_dump --version
psql -h 127.0.0.1 -U xnexdrgr_daii_app2 -d xnexdrgr_daii_staging -tAc "select version();"
```

Then run it again **with the app's stripped environment** to reproduce what
the Passenger process sees (this is the one that matters):
```bash
env -i PATH=/usr/bin:/bin HOME=/home/xnexdrgr /bin/pg_restore --list "$F"; echo "EXIT=$?"
```
If the plain-shell run works but the `env -i` run fails with a shared-library
error, the cause is a stripped `LD_LIBRARY_PATH` in the Passenger process env
(Finding 2, row 3).

**Archive-format vs pg_restore version:** if `head -c 12` shows a version
higher than what `/bin/pg_restore --version` supports (e.g. archive `1.15` from
a PG16 `pg_dump`, but `/bin/pg_restore` is PG10 → supports `1.13`), that is the
cause — the file is a valid archive that *this* `pg_restore` cannot read. The
DB is PostgreSQL 10.x, so `pg_dump` **and** `pg_restore` must both be a
PG ≥ 10 client of the **same or compatible** major version. `/bin/pg_dump` and
`/bin/pg_restore` being different versions is the trap.

---

## Finding 4 — confirm the app is checking the file you verified

```bash
# what the app actually resolved RELEASE_BACKUP_STORAGE_PATH to:
grep -n 'RELEASE_BACKUP_STORAGE_PATH\|storagePath' \
  /home/xnexdrgr/daii.xnexustech.com/release-new/backend/dist/foundation/configuration/*.js
# the cPanel env value:
#   cPanel -> Setup Node.js App -> Environment variables -> RELEASE_BACKUP_STORAGE_PATH
# it MUST be an absolute path (= /home/xnexdrgr/backups/daii). If unset, it
# defaults to ./storage/backups relative to the app cwd, i.e.
#   /home/xnexdrgr/daii.xnexustech.com/release-new/backend/storage/backups/db/3facc830-....dump
ls -l /home/xnexdrgr/daii.xnexustech.com/release-new/backend/storage/backups/db/ 2>/dev/null
```
If a stale/bad `3facc830-….dump` exists under the *relative* path, the app is
verifying that one, not the good one you checked under `/home/xnexdrgr/backups/daii`.
(The manifest for this run — `<RELEASE_BACKUP_STORAGE_PATH>/manifests/3facc830-….json`
— records the path and the SHA-256 the artifact was created with; compare
`sha256sum "$F"` to `artifacts[].sha256` in that JSON.)

---

## What to report back (then stop)

1. Finding 1 grep results — is the running `dist` old or fixed?
2. Finding 2 — the exact line(s) from `stderr.log` after `pg_restore --list failed for`.
3. Finding 3 — `/bin/pg_restore --list "$F"` **exact stdout tail + stderr + EXIT code**, the `wc -c` TOC size, `/bin/pg_restore --version`, `/bin/pg_dump --version`, `select version()`, and the `head -c 12 | od` bytes.
4. Finding 3 `env -i` run — exit + stderr.
5. Finding 4 — the resolved `RELEASE_BACKUP_STORAGE_PATH`, whether a file exists under the relative fallback path, and whether `sha256sum "$F"` matches the artifact's recorded `sha256` in the run manifest.

That set pinpoints it to exactly one of: **(a)** old `dist` + 1 MiB maxBuffer,
**(b)** `/bin/pg_restore` too old for the archive format, **(c)** stripped
Passenger env / missing libpq, **(d)** wrong file path. No change is made in
this diagnosis.

## Confirmations

| | |
|---|---|
| Application logic changed | **No** |
| Database data changed | **No** |
| New backup created | **No** |
| BackupRun / artifact deleted | **No** |
| UUID audit / plan / execute | **Not run** — `03c435b6-…` untouched |
| ModSecurity | not touched here (already resolved by the operator) |
