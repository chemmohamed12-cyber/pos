# Backup Gate Fix — 12-file surgical delta

Applies the Backup Gate Fix onto a server that already has the Release Center
(from an earlier bootstrap) but is running the OLD `dist` — the case where
`verifyArtifact` reports `pg_restore --list could not parse the dump — archive
is not structurally valid.` for a manually-confirmed-valid PGDMP dump.

**12-file overlay. `rsync` WITHOUT `--delete`. No migrations, no `npm install`,
no dependency change. UUID Repair Run 03c435b6-… is not touched. Do NOT create
a new backup.**

## Files (paths mirror `<AppRoot>` = `/home/xnexdrgr/daii.xnexustech.com/release-new/backend`)

```
src/foundation/release/{pg-dump-runner.service,backup-manager.service,release.controller}.ts
dist/foundation/release/{pg-dump-runner.service,backup-manager.service,release.controller}.{js,d.ts,js.map}
```

## Steps

```bash
AR=/home/xnexdrgr/daii.xnexustech.com/release-new/backend
cd <extracted>/Daii-BackupGateFix-Delta-2026-08-31

# 0. integrity of this package
sha256sum -c MANIFEST.sha256                         # OK for all 12

# 1. local rollback copy of the 3 files being replaced
for f in pg-dump-runner.service backup-manager.service release.controller; do
  cp -a "$AR/dist/foundation/release/$f.js" "$AR/dist/foundation/release/$f.js.pre-bgf"
done

# 2. overlay — NO --delete
rsync -a  src/foundation/release/  "$AR/src/foundation/release/"
rsync -a  dist/foundation/release/ "$AR/dist/foundation/release/"

# 3. confirm the running dist now has the fix
grep -c 'maxBuffer' "$AR/dist/foundation/release/pg-dump-runner.service.js"   # >= 3
grep -c 'PGDMP'      "$AR/dist/foundation/release/pg-dump-runner.service.js"  # 1
grep -c 'structural' "$AR/dist/foundation/release/backup-manager.service.js"  # >= 1  (uses structural.ok / structural.detail)
grep -c 'redactErrorForResponse' "$AR/dist/foundation/release/release.controller.js"  # >= 7

# 4. restart Passenger
touch "$AR/tmp/restart.txt"
```

## Re-verify the EXISTING artifact

```bash
curl -sS -X POST \
  "https://daii.xnexustech.com/api/release/backups/artifacts/316abf30-f3ac-41f8-8046-b6c9de96d2c1/verify" \
  -H "Authorization: Bearer <ADMIN_JWT>" -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 daii-ops" --data '{}'

curl -sS "https://daii.xnexustech.com/api/release/backups/3facc830-ed83-42f1-86d4-97bc76d5b81e" \
  -H "Authorization: Bearer <ADMIN_JWT>" -H "User-Agent: Mozilla/5.0 daii-ops"
```

**Acceptance:** the `database` artifact → `status: "verified"`, `verifiedAt` set,
`errorMessage: null`, id still `316abf30-…`. Repair run `03c435b6-…` still
`planned`. **Then STOP and report.**

## If it STILL fails after the fix

The new code records the REAL reason on `artifact.errorMessage`. Read it. The
top remaining candidate is a **path mismatch** — the app verifying a different
file than the one you manually confirmed:

```bash
# what RELEASE_BACKUP_STORAGE_PATH resolves to (cPanel env; unset => ./storage/backups relative to $AR)
grep -rn "RELEASE_BACKUP_STORAGE_PATH" "$AR/dist/foundation/configuration/"
# is there a SECOND file at the relative fallback?
F2="$AR/storage/backups/db/3facc830-ed83-42f1-86d4-97bc76d5b81e.dump"
ls -l "$F2" 2>/dev/null ; head -c 5 "$F2" 2>/dev/null; echo
# the run manifest records the path + sha used when the artifact was created:
find /home/xnexdrgr -name '3facc830-ed83-42f1-86d4-97bc76d5b81e.json' 2>/dev/null -exec cat {} \;
sha256sum /home/xnexdrgr/backups/daii/db/3facc830-ed83-42f1-86d4-97bc76d5b81e.dump
# compare that sha to artifacts[].sha256 in the manifest and to the artifact row's checksumSha256
```

If the artifact's recorded `checksumSha256` is of a BAD file and the good file
is elsewhere, the artifact cannot be re-verified (its checksum is frozen) —
**stop and report that**; do not create a new backup or move files without
instruction.
