# UUID Repair — polymorphic-reference gap fix

Closes the post-repair console errors:
`No process instance for {pick_task,pack_task,shipment,warehouse_transaction}/<id> — call start() first.`
and the resulting `GET /api/fulfillment/*` `/api/shipments` `/api/warehouse-transactions/overview` **404s**.

Root cause + full analysis: `UUID_REPAIR_POLYMORPHIC_GAP_REPORT.md` (in this package).

## Two parts

### PART 1 — corrective SQL for staging (run this to fix the live errors)

`tools/data-repair/repair-polymorphic-refs.sql` — mapping-driven from the
existing `data_repair_run`. Updates ONLY `process_instances.entityId`
(6 entityTypes the repair missed) + `scope_assignments.resourceId`
(`customer`) where they still carry a repaired old id. No PK change, no
audit/plan/execute re-run, one transaction, COMMIT only if all AFTER orphan
counts = 0.

```bash
AR=/home/xnexdrgr/daii.xnexustech.com/release-new/backend
# put the SQL on the host (it's only in tools/, not runtime):
rsync -a tools/data-repair/repair-polymorphic-refs.sql "$AR/tools/data-repair/"

psql -h 127.0.0.1 -U xnexdrgr_daii_app2 -d xnexdrgr_daii_staging \
  -v repair_run_id="'<THE data_repair_run id — the completed 764-row run>'" \
  -f "$AR/tools/data-repair/repair-polymorphic-refs.sql"
```
Read the BEFORE / repaired-count / AFTER blocks it prints. If any AFTER
`orphans` > 0 → it will have `ROLLBACK`-ed (ON_ERROR_STOP); investigate before
retrying. If it COMMITs, the app needs **no restart** for this (data-only).

### PART 2 — deploy the core fix (prevents recurrence in any future repair)

4-file overlay, `rsync` WITHOUT `--delete`:
```
src/database/uuid-repair.core.ts
dist/database/uuid-repair.core.{js,d.ts,js.map}
```
```bash
sha256sum -c MANIFEST.sha256
cp -a "$AR/dist/database/uuid-repair.core.js" "$AR/dist/database/uuid-repair.core.js.pre-poly"
rsync -a src/database/  "$AR/src/database/"     # NO --delete
rsync -a dist/database/ "$AR/dist/database/"    # NO --delete
grep -c "process_instances" "$AR/dist/database/uuid-repair.core.js"   # >= 8 (was ~3)
touch "$AR/tmp/restart.txt"
```

## Acceptance (close the phase)

- [ ] `repair-polymorphic-refs.sql` COMMITs — all AFTER orphan counts 0
- [ ] `GET /api/fulfillment/pick-tasks`, `/api/fulfillment/pack-tasks`, `/api/shipments`, `/api/warehouse-transactions/overview` → **200**, not 404
- [ ] pick/pack task, shipment, warehouse-transaction detail views → no `No process instance` console error
- [ ] `POST /api/treasury/cash-in` + `POST /api/deposits/:id/approve` with repaired ids → 2xx, no UUID error (re-confirm the original acceptance)
- [ ] pre-repair backup + `data_repair_runs` row retained

## Guardrails

- No new backup. No re-run of audit / plan / execute. No PK changed.
- `scope_assignments` change is `resourceType='customer'` only.
- ModSecurity / LiteSpeed not touched.
