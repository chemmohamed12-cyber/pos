# UUID Repair — polymorphic-reference gap (post-repair console errors)

**After** the Controlled UUID Data Repair on staging (`data_repair_run`, 764
rows, `integrityResult.passed: true`), the frontend console shows:

```
GET /api/fulfillment/pack-tasks            404 (Not Found)
GET /api/fulfillment/pick-tasks            404 (Not Found)
GET /api/shipments                         404 (Not Found)
GET /api/warehouse-transactions/overview   404 (Not Found)
Uncaught (in promise) H: No process instance for fulfillment_task/pack_task/bcbd3411-… — call start() first.
Uncaught (in promise) H: No process instance for fulfillment_task/pick_task/145fb0f3-… — call start() first.
Uncaught (in promise) H: No process instance for shipment_lifecycle/shipment/08cf2778-… — call start() first.
Uncaught (in promise) H: No process instance for warehouse_transaction/2f52ba09-… — call start() first.
```

## Root cause — ONE bug, both symptoms

The ids in those errors are all **NEW (repaired)** primary keys:

| entity in the error | repair mapping |
|---|---|
| `pack_task/bcbd3411-…` | `pack_tasks` `825844bd-…` → `bcbd3411-…` |
| `pick_task/145fb0f3-…` | `pick_tasks` `11ce82db-…` → `145fb0f3-…` |
| `shipment/08cf2778-…` | `shipments` `15b439e4-…` → `08cf2778-…` |
| `warehouse_transaction/2f52ba09-…` | `warehouse_transactions` `9c1cbe02-…` → `2f52ba09-…` |

`process_instances` is a polymorphic table keyed by
`(definitionKey, entityType, entityId)` where **`entityId` is a plain text
column with no FK**. `ProcessEngineService.getState()` throws
`NotFoundException` (→ **HTTP 404**) when no row matches an entity's *current*
id.

The repair's `POLYMORPHIC_REFERENCES` list contained **only** the
`entityType = 'sales_order'` mapping. So when a `pack_tasks` / `pick_tasks` /
`shipments` / `warehouse_transactions` / `sales_invoices` / `return_requests`
primary key was rewritten, its `process_instances.entityId` was **left
pointing at the old id**.

**Why the 404s on list endpoints:** `GET /api/fulfillment/pick-tasks`,
`/api/shipments`, `/api/warehouse-transactions/overview` (and the matching
detail views) enrich each row with its process state via
`processEngine.getState(...)`. One un-remapped row → `getState` throws →
`NotFoundException` → the **whole endpoint returns 404**. Same bug, surfaced
as an HTTP status instead of a console throw.

**Also missed:** `scope_assignments.resourceId` (text, no FK, keyed by
`(userId, resourceType, resourceId)`, only ever `resourceType = 'customer'`)
— a repaired `customers.id` leaves the sales-rep scope assignment orphaned.

**Why `integrityResult.passed` was `true`:** the integrity verification had
FK-orphan checks for real and soft FKs, but **no check for polymorphic
`entityId` / `resourceId` orphans**. Fixed now (see below).

## The FULL polymorphic map (compiled from every call site)

| discriminator | referencing column | target table |
|---|---|---|
| `entityType = 'sales_order'` | `process_instances.entityId` | `sales_orders` *(was covered)* |
| `entityType = 'sales_invoice'` | `process_instances.entityId` | `sales_invoices` |
| `entityType = 'warehouse_transaction'` | `process_instances.entityId` | `warehouse_transactions` |
| `entityType = 'return_request'` | `process_instances.entityId` | `return_requests` |
| `entityType = 'shipment'` | `process_instances.entityId` | `shipments` |
| `entityType = 'pack_task'` | `process_instances.entityId` | `pack_tasks` |
| `entityType = 'pick_task'` | `process_instances.entityId` | `pick_tasks` |
| `custodianType = 'company'` | `return_requests.custodianId` | `shipping_companies` *(was covered)* |
| `custodianType = 'vehicle'` | `return_requests.custodianId` | `vehicles` *(was covered)* |
| `resourceType = 'customer'` | `scope_assignments.resourceId` | `customers` |

## Fix — two parts

### Part 1 — corrective data repair for staging (run this to CLOSE the phase)

`tools/data-repair/repair-polymorphic-refs.sql` — **mapping-driven from the
existing `data_repair_run` row**, so it corrects exactly the ids that were
rewritten, nothing else:

- reads `data_repair_runs.mapping` for the given run id
- updates **only** `process_instances.entityId` (6 missed entityTypes) and
  `scope_assignments.resourceId` (`customer`) where they still carry an old id
- **no primary key is changed; no audit/plan/execute is re-run**
- one transaction, with BEFORE/AFTER orphan counts printed — **COMMIT only if
  every AFTER count is 0**, else `ROLLBACK`
- records `integrityResult.polymorphicCorrection` on the run row for evidence

```bash
psql -h 127.0.0.1 -U xnexdrgr_daii_app2 -d xnexdrgr_daii_staging \
  -v repair_run_id="'<THE data_repair_run id>'" \
  -f tools/data-repair/repair-polymorphic-refs.sql
```

Preconditions: the verified pre-repair backup is still retained (this
correction is additive text-column updates, but the backup stays the rollback
path). No new backup, no application change needed for the correction itself.

### Part 2 — `src/database/uuid-repair.core.ts` (prevents recurrence)

- `POLYMORPHIC_REFERENCES` now has all 10 entries (the 7 above + the 3 that
  were already there).
- `verifyUuidRepairIntegrity()` adds an **orphan (polymorphic)** check per
  entry — `count(referencing rows WHERE discriminator matches AND id not in
  target)`; a future run with this gap would now fail `passed`.
- 2 regression tests (`uuid-repair.core.spec.ts`): the polymorphic map covers
  every process `entityType`; `runUuidRfc4122Repair` remaps a repaired PK in
  `process_instances.entityId` discriminator-scoped and leaves unrelated rows
  alone.
- The deferred `RepairNonCompliantUuids` migration is a thin wrapper over the
  core, so it inherits the fix automatically.

Full suite after: **57 suites / 700 tests green**; build + lint (19
pre-existing) + structure + dist-integrity clean.

## After running Part 1 — acceptance to close the phase

- [ ] `repair-polymorphic-refs.sql` COMMITs (all AFTER orphan counts = 0)
- [ ] `GET /api/fulfillment/pick-tasks`, `/api/fulfillment/pack-tasks`, `/api/shipments`, `/api/warehouse-transactions/overview` → **200**, not 404
- [ ] opening a pick task / pack task / shipment / warehouse transaction detail view → no `No process instance … call start() first` in the console
- [ ] `POST /api/treasury/cash-in` and `POST /api/deposits/:id/approve` with repaired ids → **2xx, no UUID error** (the original acceptance — unaffected by this, re-confirm)
- [ ] the pre-repair backup + `data_repair_runs` row (mapping + integrityResult) retained as evidence

## Not caused by this / out of scope

- No other polymorphic text columns exist (`audit_records.before/after`,
  `event_outbox.payload`, `idempotency_records.responseBody` are
  point-in-time JSON history — deliberately never rewritten).
- `process_transition_records.processInstanceId` is a real FK to
  `process_instances.id` (a repaired PK there is handled by the DB-enforced
  FK loop) — unaffected.
